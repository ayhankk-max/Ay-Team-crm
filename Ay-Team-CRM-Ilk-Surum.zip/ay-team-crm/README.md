# Ay Team CRM — ilk çalışan prototip

`index.html` dosyasını tarayıcıda açarak deneyebilirsiniz. Portföy, alıcı talebi, arama takibi, danışman profil fotoğrafı ve yetki süresi bitimine 7 gün kala uyarı gösterimi içerir.

**Önemli:** Bu sürüm yalnızca tarayıcıda `localStorage` kullanır. Gerçek müşteri bilgilerini bu prototipe girmeyin. Kullanıcı giriş sistemi, ekipler arası yetkilendirme, komisyon gizliliği ve sunucu tabanlı kayıt henüz uygulanmamıştır. Bunlar Supabase kimlik doğrulaması ve satır düzeyi güvenlik kurallarıyla ayrıca kurulmalıdır. Yetki bitiş uyarıları yalnızca uygulama açıldığında görünür, otomatik e-posta/bildirim göndermez.
